import React, { useState, useEffect } from "react";
import Viewmodal from "./Viewmodal";
import Editmodal from "./Editmodal";
import Data from "../Data.json";
const Table = () => {
  const [data, setData] = useState(Data);

  const [i, setIndex] = useState();

  const [getStatus, setGetStatus] = useState();

  const [status, setStatus] = useState("pending");
  
  console.log(data);


  return (
    <div>
        <h1 class="text-center">Order status for Makers</h1>
      <table className='table table-striped mt-5'>
        <thead className='thead-light'>
          <tr>
            <th scope='col'>Order Id</th>
            <th scope='col'>Date</th>
            <th scope='col'>Status</th>
            <th scope='col'>Delivery Address</th>
            <th scope='col'>Action</th>
          </tr>
        </thead>
        <tbody>
          {data.map((curr, index) => {
           
           //Destructing
            const {
              order_id,
              date,
              status,
              delivery_address,
              order_details,
            } = curr;
            if(i == index) {
              console.log(getStatus);
            } 
            return (
              
              <tr key={index}>
                {console.log(curr.status)}
                <th scope='row'>{order_id}</th>
                <td>{date}</td>
               <td>
                 <span className={status == 'Pending' ? 'badge badge-warning' : status == 'Completed' ? 'badge badge-success' : status == 'Building' ? 'badge badge-secondary' : status == 'Delivered' ? 'badge badge-danger' : ''}>{status}</span>   
              </td>
                <td>{delivery_address}</td>
                <td className='d-flex'>
                  <Editmodal setIndex = {setIndex} index = {index} getStatus= {setGetStatus}
                    /* onChange={(value) => {
                      setData(value);
                    }} */
                    order_id={order_id}
                  />
                  <Viewmodal order_details={order_details} />
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};

export default Table;
