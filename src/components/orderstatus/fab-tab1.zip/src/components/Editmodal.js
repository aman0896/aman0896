import React, { useEffect, useState } from "react";
import data from "../Data.json";
import './Editmodal.css'
import { FaEdit } from 'react-icons/fa';

const Editmodal = ({ order_id, onChange, setIndex, index, getStatus}) => {

  
  let iconStyles = { marginRight: "0.5rem" };
  const [show, showModal] = useState(false);
  
  const handleChange = (e) => {

    
    
    // Array starts from 0 so we have to do order_id -1 because our id starts with 1
    data[order_id - 1].status = e.target.value;
    // console.log(data)
    getStatus(e.target.value);
    setIndex(index);

    const json = JSON.stringify(data);
    localStorage.setItem("items", json);

    //onChange(data);
  };

  return (
    <div className='clearfix m-0'>
      <button type="button" className='openModalBtn' class="btn btn-success d-flex align-items-center" onClick={() => showModal(true)}>
      <FaEdit style={iconStyles}/>Edit
      </button>
      <div style={{ display: show ? "block" : "none" }} className='modal'>
        <div className='modal-content bounceIn clearfix'>
          <span onClick={() => showModal(false)} className='close'>
            &times;
          </span>
          <div>
            <h3 className='status_heading'>select status</h3>
            <select className='form-select' onChange={(e) => handleChange(e)}>
              <option value='Building'>Building</option>
              <option value='Pending'>Pending</option>
              <option value='Completed'>Completed</option>
              <option value='Delivered'>Delivered</option>
            </select>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Editmodal;
