import React, { useState, useEffect } from "react";
import data from "../Data.json";
import Table from "./Table";

const CusTab = () => {
    const [savedItems, setSavedItems] = useState();
    
    
    useEffect(() => {
        const json = localStorage.getItem("items");
        setSavedItems(JSON.parse(json));
       // const savedItems = JSON.parse(json);
    },[]);
    
    return (
        <div>
          <h1 class="text-center">Order status for Customers</h1>
      <table className='table table-striped mt-5'>
        <thead className='thead-light'>
          <tr>
            <th scope='col'>Order Id</th>
            <th scope='col'>Date</th>
            <th scope='col'>Status</th>
            <th scope='col'>Amount</th>
          </tr>
        </thead>
        <tbody>
            { savedItems && 
                savedItems.map(row => (
                    <tr key={row.order_id}>
                        <th scope='row'>{row.order_id}</th>
                        <td>{row.date}</td>
                        <td>
                        <span className={row.status == 'Pending' ? 'badge badge-warning' : row.status == 'Completed' ? 'badge badge-success' : row.status == 'Building' ? 'badge badge-secondary' : row.status == 'Delivered' ? 'badge badge-danger' : ''}>{row.status}</span>
                        </td>
                        <td>{row.order_details.amount}</td>
                    </tr>
                ))
            } 
            {/* {savedItems.map(row => (
                <tr key={row.order_id}>
                    <th scope='row'>{row.order_id}</th>
                    <td>{row.date}</td>
                    <td>{row.status}</td>
                    <td>{row.order_details.amount}</td>
                </tr>
            ))} */}
        </tbody>
      </table>
    </div>
    );
};

export default CusTab;
