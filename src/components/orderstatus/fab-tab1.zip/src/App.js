import './App.css';
import Table from './components/Table';
import CusTab from './components/Cust-Table';
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";

//import cusTab from './components/Cust-Table';

function App() {
  return (
    <Router>
      <div className="App">
      <Route path = "/CusTab" component= {CusTab}/> 
      <Route path = "/Table" component = {Table}/>      
    </div>
    </Router>
     
  );
}

export default App;
